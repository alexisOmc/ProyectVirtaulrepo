//
//  CellCollectionViewCollectionViewCell.swift
//  VirtualTourist.Udacity
//
//  Created by Alexis Omar Marquez Castillo on 05/11/20.
//  Copyright © 2020 udacity. All rights reserved.
//
import Foundation
import UIKit
class CellCollectionViewCollectionViewCell: UICollectionViewCell {
    // MARK: - Outlets
    
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var cellActivityIndicator: UIActivityIndicatorView!



}
